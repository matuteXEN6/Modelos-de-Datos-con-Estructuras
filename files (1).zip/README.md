# SISTEMAPROYECTO

## Materia
Laboratorio de Programación - EEST N.º 1 "Eduardo Ader" Vicente López
5° año 3° Grupos A-B

## Integrantes
- [Apellido y Nombre 1]
- [Apellido y Nombre 2]
- [Apellido y Nombre 3]

## Descripción del Modelo
Este repositorio corresponde a la Actividad 5: Modelado de datos con Estructuras (struct) y Punteros en C++, en conexión con el Proyecto Integrador Anual del grupo.

El programa modela una entidad del mundo real (sensor, módulo de hardware o usuario) mediante una estructura (`struct`), controlando el ingreso y la modificación de sus miembros por referencia a través de punteros y el operador flecha (`->`).

## Estructura del Repositorio
```
SISTEMAPROYECTO/
├── .gitignore
├── LICENSE
├── README.md
├── Docs/
│   └── manuales/
│       └── manual_programador_v1.0.0.md
├── src/
│   └── main.cpp
└── Capturas/
    └── ejecucion_struct.png
```

## Compilación y Ejecución (Windows / PowerShell / VS Code)
```
g++ src/main.cpp -o src/sistema.exe
.\src\sistema.exe
```

## Ramas
- `main`: versión estable
- `development`: desarrollo en curso
